import json
import requests
from bs4 import BeautifulSoup

def lambda_handler(event, context):
    # 1. HTTP 요청 (requests)
    response = requests.get('https://example.com')

    # 2. html -> bs4 파싱 (bs4)
    soup = BeautifulSoup(response.text, 'html.parser')

    # 3. bs4 객체에서 데이터 추출
    h1_tags = []
    for tag in soup.find_all('h1'):
        h1_tags.append(tag.text)

    return {
        'statusCode': 200,
        'body': json.dumps(h1_tags)
    }
